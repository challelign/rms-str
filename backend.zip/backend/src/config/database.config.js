/*module.exports = {
  HOST: "localhost",
  USER: "admin",
  PASSWORD: "admin123;",
  DATABASE: "rmr",
};*/

module.exports = {
	HOST: "localhost",
	USER: "root",
	PASSWORD: "",
	DATABASE: "rmr",
};
